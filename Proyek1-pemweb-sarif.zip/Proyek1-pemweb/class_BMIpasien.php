<?php
class BMIpasien{
    public $bmi;
    public $tanggal;
    public $pasien;

    function __construct($bmi, $tanggal, $pasien){
        $this->bmi;
        $this->tanggal;
        $this->pasien;
    }

}
?>